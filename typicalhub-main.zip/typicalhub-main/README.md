# typicalhub

free hub lol, scripts are open sourced encluding the simple reanimation. leaking is for skids, but if you do its a free hub i could care less
